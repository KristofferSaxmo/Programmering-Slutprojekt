﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace Template
{
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D Block1, Block2, Block3, Block4, Block5, Block6, Block7;

        List<Vector2> Tetromino = new List<Vector2>();

        KeyboardState Keyboard;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            graphics.PreferredBackBufferWidth = 480;
            graphics.PreferredBackBufferHeight = 800;
            graphics.ApplyChanges();
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            Block1 = Content.Load<Texture2D>("1");
            Block2 = Content.Load<Texture2D>("2");
            Block3 = Content.Load<Texture2D>("3");
            Block4 = Content.Load<Texture2D>("4");
            Block5 = Content.Load<Texture2D>("5");
            Block6 = Content.Load<Texture2D>("6");
            Block7 = Content.Load<Texture2D>("7");
        }

        protected override void UnloadContent()
        {
        }

        protected override void Update(GameTime gameTime)
        {
            Keyboard = Microsoft.Xna.Framework.Input.Keyboard.GetState();
            if (Keyboard.IsKeyDown(Keys.Escape))
                Exit();

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            base.Draw(gameTime);
        }
    }
}
