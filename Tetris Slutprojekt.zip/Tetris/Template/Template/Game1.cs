﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace Template
{
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        private Texture2D Block;

        private Texture2D SpelplanTex;

        private Vector2 spelarPosition = new Vector2(0, 0);
        private Vector2 gammalSpelarPosition = new Vector2(0, 0);

        private List<Vector2> Tetromino = new List<Vector2>(); // Position för alla tetrominos

        private KeyboardState Keyboard;

        private int SpelareFallTimer = 0;

        private int Falltid = 48;

        private int blockAntal = 0;

        private Random Random = new Random();

        private bool Högeraktiv = false, Vänsteraktiv = false, Neraktiv = false;

        private int[,] Spelplan = new int[10, 20];



        private Rectangle SpelareRec, SpelplanRec = new Rectangle(0, 0, 480, 960);

        private I TetrominoI = new I();

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            graphics.PreferredBackBufferWidth = 720;
            graphics.PreferredBackBufferHeight = 960;
            graphics.ApplyChanges();
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            Block = Content.Load<Texture2D>("Block");

            Spelplan = new Texture2D(GraphicsDevice, 1, 1);
            Spelplan.SetData(new[] { Color.White });
        }

        protected override void UnloadContent()
        {
            base.UnloadContent();
            spriteBatch.Dispose();
            Spelplan.Dispose();
        }

        protected override void Update(GameTime gameTime)
        {
            Keyboard = Microsoft.Xna.Framework.Input.Keyboard.GetState();

            if (Keyboard.IsKeyDown(Keys.Escape)) // Sluta spela
                Exit();

            SpelarRörelse();

            Kollision();

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.DarkGray);
            spriteBatch.Begin();

            spriteBatch.Draw(Spelplan, new Rectangle(0, 0, 480, 960), Color.Black);

            spriteBatch.Draw(Block, spelarPosition, Color.LightBlue);

            foreach (Vector2 Tetromino in Tetromino)
            {
                Rectangle TetrominosRec = new Rectangle();
                TetrominosRec.Location = Tetromino.ToPoint();
                TetrominosRec.Size = new Point(48, 48);
                spriteBatch.Draw(Block, TetrominosRec, Color.Red);
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }

        private void Kollision()
        {
            SpelareRec = new Rectangle((int)spelarPosition.X, (int)spelarPosition.Y, 48, 48);
            if (!SpelareRec.Intersects(SpelplanRec))
            {
                spelarPosition = gammalSpelarPosition;
                blockAntal++;
            }
        }

        private void RandomTetromino()
        {

        }

        private void SpelarRörelse()
        {
            SpelareFallTimer++; // Fall av spelarens tetromino

            gammalSpelarPosition = spelarPosition;

            if (SpelareFallTimer == Falltid)
            {
                spelarPosition.Y += 48;
                SpelareFallTimer = 0;
            }


            if (Keyboard.IsKeyDown(Keys.Right) && Högeraktiv == false) // Gå höger
            {
                spelarPosition.X += 48;
                Högeraktiv = true;
            }
            else if (Keyboard.IsKeyUp(Keys.Right))
                Högeraktiv = false;


            if (Keyboard.IsKeyDown(Keys.Left) && Vänsteraktiv == false) // Gå vänster
            {
                spelarPosition.X -= 48;
                Vänsteraktiv = true;
            }
            else if (Keyboard.IsKeyUp(Keys.Left))
                Vänsteraktiv = false;


            if (Keyboard.IsKeyDown(Keys.Down) && Neraktiv == false) // Gå ner
            {
                spelarPosition.Y += 48;
                Neraktiv = true;
                SpelareFallTimer = 0;
            }
            else if (Keyboard.IsKeyUp(Keys.Down))
                Neraktiv = false;
        }
    }
}