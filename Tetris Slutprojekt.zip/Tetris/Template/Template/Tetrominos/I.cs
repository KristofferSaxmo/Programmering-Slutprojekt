﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template
{
    enum Rotation
    {
        One, Two, Three, Four
    }
    class I
    {
        int[,] tetrominoI = { { 0, 0, 0, 0 },
                              { 1, 1, 1, 1 },
                              { 0, 0, 0, 0 },
                              { 0, 0, 0, 0 } };
        Vector2 position;
        Texture2D texture;
        Rotation rotation = Rotation.One;
        public void Update()
        {
            position.Y++;
        }
    }
}
